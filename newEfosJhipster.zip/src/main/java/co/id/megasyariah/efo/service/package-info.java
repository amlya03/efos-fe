/**
 * Service layer beans.
 */
package co.id.megasyariah.efo.service;
