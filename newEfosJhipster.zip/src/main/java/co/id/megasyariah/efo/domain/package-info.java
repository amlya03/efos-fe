/**
 * JPA domain objects.
 */
package co.id.megasyariah.efo.domain;
