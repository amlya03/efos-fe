/**
 * Data Transfer Objects.
 */
package co.id.megasyariah.efo.service.dto;
