/**
 * Data Access Objects used by WebSocket services.
 */
package co.id.megasyariah.efo.web.websocket.dto;
