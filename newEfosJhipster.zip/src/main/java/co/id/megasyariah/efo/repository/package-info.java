/**
 * Spring Data JPA repositories.
 */
package co.id.megasyariah.efo.repository;
