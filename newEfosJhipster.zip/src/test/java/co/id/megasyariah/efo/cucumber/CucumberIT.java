package co.id.megasyariah.efo.cucumber;

import co.id.megasyariah.efo.IntegrationTest;
import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
@IntegrationTest
class CucumberIT {}
